<?php $__env->startSection('maincontent'); ?>

<h1 style="float: left">Cart Products</h1><h4 style="float: right;"><button class="btn btn-primary"><a style="color: white" href="/clear_cart">Clear Cart</a> </button></h4>
	<hr>
	<table class="w3-table-all w3-centered">
    
    <tr>
	    <th>Id</th>
      	<th>Product name</th>
	    <th>Price</th>
	    <th>Quantity</th>
		<th>Sub total</th>
		<th>Remove product</th>
    </tr>
    
    <?php
		  $i =0; 
		  $total = 0;
		?>

    <?php $__currentLoopData = $cart_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      	<tr>
	    	<td><?php echo e(++$i); ?></td>
	    	<td><?php echo e($p->name); ?></td>
	        <td><?php echo e($p->price); ?></td>
	        <td><?php echo e($p->quantity); ?>

				<!--<form method="POST" action="/update_cart">
					<?php echo csrf_field(); ?>

		        	<input type="number" value="<?php echo e($p->quantity); ?>" min="1" name="quantity">
		        	<input type="hidden" value="<?php echo e($p->id); ?>" name="product_id" >
	        		<input type="submit" value="update">
				</form>-->
			</td> 
			<?php 
				$subtotal = $p->quantity*$p->price;
				$total = $total + $subtotal;
			?>
			<td><?php echo e($subtotal); ?>.00 Tk</td>
			<td><a href="<?php echo e(url('/remove_product/'.$p->id)); ?>">Remove</a></td>
      	</tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    	<tr>
    		<td></td>
    		<td></td>
    		<td></td>
    		<td>Total</td>
    		<td><?php echo e($total); ?>.00 Tk</td>
    	</tr>

    
  </table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.homepage_with_logout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Arun kundu\Desktop\Ecommerce1\Ecommerce1\resources\views/user/home/cart_show.blade.php ENDPATH**/ ?>