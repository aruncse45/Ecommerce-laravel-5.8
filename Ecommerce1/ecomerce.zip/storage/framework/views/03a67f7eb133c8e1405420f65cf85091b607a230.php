<?php $__env->startSection('maincontent'); ?>

	<h1>MANEGE PRODUCT</h1>
	<hr>
	<table class="w3-table-all w3-centered">
    
    <tr>
    	<th>id</th>
      <th>Category</th>
      <th>product name</th>
      <th>Description</th>
      <th>price</th>
      <th>image</th>
      <th>change</th>
    </tr>
    
    <?php
		  $i =0; 
		?>

    <?php $__currentLoopData = $productinfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
    		<td><?php echo e(++$i); ?></td>
        <td><?php echo e($p->category); ?></td>
    		<td><?php echo e($p->model_name); ?></td>
    		<td><?php echo e($p->description); ?></td> 
        <td><?php echo e($p->price); ?></td>
        <td><img style="height: 50px; width: 50px" src="<?php echo e(URL::asset('admin/upload_image/'.$p->image)); ?>"></td>
        <td><a href="<?php echo e(url('/edit_product/'.$p->id)); ?>"><button class="btn btn-primary">UPDATE</button></a><a href="<?php echo e(url('/delete_product/'.$p->id)); ?>">   <button class="btn btn-primary">DELETE</button></a></td>
      </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    
  </table>


<?php echo e($productinfo->links()); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.adminpage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Arun kundu\Desktop\Ecommerce1\Ecommerce1\resources\views/admin/product/manage_product.blade.php ENDPATH**/ ?>