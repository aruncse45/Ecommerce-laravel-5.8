<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class product_info extends Model
{
    //
}
