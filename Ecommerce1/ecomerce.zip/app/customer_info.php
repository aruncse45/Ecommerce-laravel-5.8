<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class customer_info extends Model
{
    //
}
